<?php
function convdate($inp)
{
$inp=explode(" ",$inp)[0];
if($inp!="")
{
if(strrpos($inp,"-")>0) // `-` contain date
$inparr=explode("-",$inp);
else if(strrpos($inp,"/")>0) // `/` contain date	
$inparr=explode("/",$inp);

$res=$inparr[2]."-".$inparr[1]."-".$inparr[0];
}
else
$res="";

return $res;
}
?>


<?php $__env->startSection('content'); ?>
    <div style="margin-top:50px" class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Comment Detail </h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(url('comment\create')); ?>" title="Create a comment"> <i class="fas fa-plus-circle"></i>
                    </a>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered table-responsive-lg">
        <tr>
            <th>No</th>
			<th>Title</th>
            <th>Comment</th>
            <th>Actions</th>
        </tr>
		
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e(print_r($comment->pivot)); ?><?php echo e(dd()); ?>

		<?php //try{ ?>
            <tr>
                <td><?php echo e($sno++); ?></td>
				<td>
				 <?php $__currentLoopData = $comment->tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($val->title); ?>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</td>
                <td>
					<?php echo e($comment->comment); ?>

				
				</td>
                
                <td>
                    <form action="<?php echo e(url('comment/'.$comment->{'comment.id'})); ?>" method="post">

                        <a href="<?php echo e(url('comment/'.$comment->id)); ?>" title="show">
                            <i class="fas fa-eye text-success  fa-lg"></i>
                        </a>

                        <a href="<?php echo e(url('comment/'.$comment->id.'/edit')); ?>">
                            <i class="fas fa-edit  fa-lg"></i>
                        </a>

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit" title="delete" style="border: none; background-color:transparent;">
                            <i class="fas fa-trash fa-lg text-danger"></i>
                        </button>
                    </form>
                </td>
            </tr>
		<?php /*} 
		catch(Exception  $e)
		{
			
		}
		*/
		?>
		
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $comments->links(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\resources\views/comments/index.blade.php ENDPATH**/ ?>