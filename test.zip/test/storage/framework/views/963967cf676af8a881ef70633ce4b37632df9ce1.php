


<?php $__env->startSection('content'); ?>
    <div style="margin-top:50px" class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>  </h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(url('post')); ?>" title="Go back"> <i class="fas fa-backward "></i> </a>
            </div>
        </div>
    </div>

    <div class="row" style="width:78%">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong style="float:left;width:50%">Title:</strong>
				<div><?php echo e($post->title); ?></div>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong style="float:left;width:50%">Description</strong>
				<div><?php echo e($post->description); ?></div>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong style="float:left;width:50%">Image</strong>
				<img style='width:200px;height:200px' src='<?php echo e(asset($post->img)); ?>' title='Img' />
            </div>
        </div>
       
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\resources\views/posts/show.blade.php ENDPATH**/ ?>