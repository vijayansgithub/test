<?php
function convdate($inp)
{
$inp=explode(" ",$inp)[0];
if($inp!="")
{
if(strrpos($inp,"-")>0) // `-` contain date
$inparr=explode("-",$inp);
else if(strrpos($inp,"/")>0) // `/` contain date	
$inparr=explode("/",$inp);

$res=$inparr[2]."-".$inparr[1]."-".$inparr[0];
}
else
$res="";

return $res;
}
?>


<?php $__env->startSection('content'); ?>
    <div style="margin-top:50px" class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Post Details </h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(url('post/create')); ?>" title="Create a post"> <i class="fas fa-plus-circle"></i>
                    </a>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered table-responsive-lg">
        <tr>
            <th>No</th>
            <th>Title</th>
            <th>Description</th>
            <th>Image</th>
            
            <th>Actions</th>
        </tr>
		
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($sno++); ?></td>
                <td><?php echo e($post->title); ?></td>
                <td><?php echo e($post->description); ?></td>
                <td><img style='width:50px;height:50px' src='<?php echo e(asset($post->img)); ?>' title='Img' /></td>
                
                <td>
                    <form action="<?php echo e(url('post/'.$post->id)); ?>" method="post">

                        <a href="<?php echo e(url('post/'.$post->id)); ?>" title="show">
                            <i class="fas fa-eye text-success  fa-lg"></i>
                        </a>

                        <a href="<?php echo e(url('post/'.$post->id.'/edit')); ?>">
                            <i class="fas fa-edit  fa-lg"></i>
                        </a>

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit" title="delete" style="border: none; background-color:transparent;">
                            <i class="fas fa-trash fa-lg text-danger"></i>
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $posts->links(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\resources\views/posts/index.blade.php ENDPATH**/ ?>