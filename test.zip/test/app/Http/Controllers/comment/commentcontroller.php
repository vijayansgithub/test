<?php

namespace App\Http\Controllers\comment;

use App\Http\Controllers;
use App\Models\comment;
use App\Models\post;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use DB;

class commentcontroller extends BaseController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/
    public function index()
    {
		//inner join comment and post tables.
		//$comments = comment::select('comment','title','comments.id')->join("posts","posts.id","=","comments.post_id")->latest('comments.created_at')->paginate(5);
       //$comments=comment::with("post")->latest('comments.created_at')->paginate(5);
	   
	   //$comments=post::latest('posts.created_at')->paginate(5);
	   $comments=comment::with("posts")->latest('comments.created_at')->paginate(5);
	   
	   return view('comments.index', compact('comments'),["sno"=>1])
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }
	/*****************************************************************************/
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/ 
    public function create()
    {
	   //get topic options
	   $options=post::get(["id","title"]);
	   
       return view('comments.create',["options"=>$options]); 
    }
	/*****************************************************************************/
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/
    public function store(Request $request)
    {
        $request->validate([
            'comment' => 'required',
            'post_id'=>  'required'
        ]);
		
        comment::create($request->all());

        return redirect()->route('comment.index')
            ->with('success', 'Comment created successfully.');
    }
	/*****************************************************************************/
    /**
     * Display the specified resource.
     *
     * @param  \App\Models\comment  $comment
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/
    public function show(comment $comment)
    {
		//join table of post & comment
		$comments = comment::join("posts","posts.id","=","comments.post_id")->where("comments.id","=",$comment->id)->get();
        
		return view('comments.show', ["comments"=>$comments]);
    }
	/*****************************************************************************/
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\comment  $comment
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/
    public function edit(comment $comment)
    {
		//get default options
		$options=post::get(["id","title"]);
		
        return view('comments.edit', compact('comment'),["options"=>$options]);
    }
	/*****************************************************************************/
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\comment  $comment
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/
    public function update(Request $request, comment $comment)
    {
        $request->validate([
            'comment' => 'required',
            'post_id'=>  'required'
        ]);
        $comment->update($request->all());

        return redirect()->route('comment.index')
            ->with('success', 'Comment updated successfully');
    }
	/*****************************************************************************/
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\comment  $comment
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/
    public function destroy(comment $comment)
    {
        $comment->delete();

        return redirect()->route('comment.index')
            ->with('success', 'Comment deleted successfully');
    }
	/*****************************************************************************/
}
