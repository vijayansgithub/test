<?php
   
namespace App\Http\Controllers\API;
   
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;

use App\Models\User;
use App\Models\PasswordReset;

use App\Notifications\PasswordResetRequest;
use App\Notifications\PasswordResetSuccess;
use Validator;


use App\Http\Resources\User as UserResource;
   
class AuthController extends BaseController
{
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);
    }
    /**
     * Register api
     *
     * @return \Illuminate\Http\Response
     */
    public function register(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|confirmed|min:8',
           
        ]);
   
        if ( $validator->fails() ) {
            return $this->sendError('Validation Error.', $validator->errors());       
        }
   
        $input = $request->all();
        $input['password'] = Hash::make($request->password);
        $user = User::create($input);
        $token =  $user->createToken('test')->accessToken;
       
        return response()->json(['token' => $token], 200);
      
    }
   
    /**
     * Login api
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request)
    {
      
        $data = [
            'email' => $request->email,
            'password' => $request->password
        ];
 
        if ( auth()->attempt($data) ) {

            $token = auth()->user()->createToken('test')->accessToken;
            echo $token;dd();
            return response()->json(['token' => $token], 200);

        } else {

            return response()->json(['error' => 'Unauthorised'], 401);
        }
    }
    public function logout(Request $request)
    {
      
       $token=$request->user()->token();
       $token->revoke();
        return response()->json(['error' => 'Logout'], 401);
        
    }
    public function sendResetLink(Request $request) 
    {

        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
        ]);

        if( $validator->fails() ) {
            return response()->json(["error"=>$validator->errors()]);// return $this->sendError('Validation Error.', $validator->errors());       
        }

        $user = User::where('email', $request->email)->first();

        if ( !$user )
            return response()->json([
                'message' => 'We can\'t find a user with that e-mail address.'
            ], 404);

        $passwordReset = PasswordReset::updateOrCreate(
            ['email' => $user->email],
            [
                'email' => $user->email,
                'token' => Str::random(40)
            ]
        );
        
        if ( $user && $passwordReset )
            $user->notify(
                new PasswordResetRequest($passwordReset->token)
            );

        return response()->json([
            'message' => 'We have e-mailed your password reset2 link!'
        ]);
    }
    public function resetPassword(Request $request)
    {
    
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required',
            'token' => 'required|string'
        ]);

        if ( $validator->fails() ) {
            return $this->sendError('Validation Error.', $validator->errors());       
        }

        $passwordReset = PasswordReset::where([
            ['token', $request->token],
            ['email', $request->email]
        ])->first();

        if ( !$passwordReset )
            return response()->json([
                'message' => 'This password reset token is invalid.'
            ], 404);

        $user = User::where('email', $passwordReset->email)->first();

        if ( !$user )
            return response()->json([
                'message' => 'We can\'t find a user with that e-mail address.'
            ], 404);

        $user->password = Hash::make($request->password);
        $user->save();
        $passwordReset->delete();
        $user->notify(new PasswordResetSuccess($passwordReset));
        return response()->json($user);
    }

   

}