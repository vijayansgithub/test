<?php

namespace App\Http\Controllers\post;

use App\Models\post;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use DB;
use Illuminate\Support\Facades\Input as Input;

class postcontroller extends BaseController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/
    public function index()
    {
		//post table list query
        $posts = post::latest()->paginate(5);
		
		
        return view('posts.index', compact('posts'),["sno"=>1])
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }
	/*****************************************************************************/
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/
    public function create()
    {
        return view('posts.create');
    }
	/*****************************************************************************/
	//This function used for generate unique no`s
	function randomno()
	{
    $no=1; //default start with 1
    
	$lastprimid=DB::table("posts")->orderBy("id","desc")->limit(1)->get(); //get table last unique id
    $no=intval($lastprimid[0]->id)+1;  
	
    return strtotime("now").$no; //add current time
	}
	/*****************************************************************************/
	//This function is used to replace default input value to update value
	function replaceField($input,$col,$val) //array,modifier col name, modifier col value
	{
	 foreach($input as $colvar=>$colval) //iterate each inp arr
	 {
	 if($col==$colvar) //if modifier col and current column match then modified
	 {
		 $inp[$colvar]=$val;
	 }
	 $inp[$colvar]=$colval;
	 }
	 return $inp;
	}
	/*****************************************************************************/
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'description' => 'required',
            'img' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048' //filter image only
        ]);
        
		//file operations
		$img="";
		$file=$request->file("img");
		$fname=$file->getClientOriginalName();  //get file name
		
		if($file->isValid()) //if valid file generate random no & move files
		{  
		$img="images/".$this->randomno()."_".$fname;
		$file->move(base_path('\public\images'),$img);
		}
		
		//replace current img path to request value array
		$modifiedarr=$this->replaceField($request->all(),'img',$img);
		
        post::create($modifiedarr);
		
        return redirect()->route('post.index')
            ->with('success', 'Post created successfully.');
    }
	/*****************************************************************************/
    /**
     * Display the specified resource.
     *
     * @param  \App\Models\post  $post
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/
    public function show(post $post)
    {
        return view('posts.show', compact('post'));
    }
	/*****************************************************************************/
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\post  $post
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/
    public function edit(post $post)
    {
        return view('posts.edit', compact('post'));
    }
	/*****************************************************************************/
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\post  $post
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/
    public function update(Request $request, post $post)
    {
         $request->validate([
            'title' => 'required',
            'description' => 'required',
            'img' => 'required'
        ]);
		
		//file operations
		$img="";
		$file=$request->file("img");
		$fname=$file->getClientOriginalName(); //get file name
		
		if($file->isValid())  //if valid file generate random no & move files
		{  
		$img="images/".$this->randomno()."_".$fname;
		$file->move(base_path('\public\images'),$img);
		}
		
		//replace current img path to request value array
		$modifiedarr=$this->replaceField($request->all(),'img',$img);
		
        $post->update($modifiedarr);

        return redirect()->route('post.index')
            ->with('success', 'Post updated successfully');
    }
	/*****************************************************************************/
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\post  $post
     * @return \Illuminate\Http\Response
     */
	/*****************************************************************************/
    public function destroy(post $post)
    {
        $post->delete();

        return redirect()->route('post.index')
            ->with('success', 'Post deleted successfully');
    }
	/*****************************************************************************/
}
