<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;

    public function sendResetLink(Request $request) 
    {

        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
        ]);

        if( $validator->fails() ) {
            return response()->json(["error"=>$validator->errors()]);//return $this->sendError('Validation Error.', $validator->errors());       
        }

        $user = User::where('email', $request->email)->first();

        if ( !$user )
            return response()->json([
                'message' => 'We can\'t find a user with that e-mail address.'
            ], 404);

        $passwordReset = PasswordReset::updateOrCreate(
            ['email' => $user->email],
            [
                'email' => $user->email,
                'token' => Str::random(40)
            ]
        );
        
        if ( $user && $passwordReset )
            $user->notify(
                new PasswordResetRequest($passwordReset->token)
            );

        return response()->json([
            'message' => 'We have e-mailed your password reset3 link!'
        ]);
    }
}
