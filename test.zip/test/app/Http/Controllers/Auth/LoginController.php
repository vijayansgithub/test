<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\API\BaseController;
use App\Http\Middleware;
use App\Models\User;
use Laravel\Passport\HasApiTokens;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;

use App\Notifications\PasswordResetRequest;
use App\Notifications\PasswordResetSuccess;
use Validator;

use App\Http\Resources\User as UserResource;
class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth.basic'); 
    }
	
	public function index()
	{
		return view("Auth.Login");
	}
    public function store(Request $request)
    {
       $email="";
       $password="";
      
        $data = [
            'email' => $request->email,
            'password' => $request->password
        ];
 
        if ( auth()->attempt($data) ) {

            $token = auth()->user()->createToken('test')->accessToken;
            return response()->json(['token' => $token], 200);

        } else {

            return response()->json(['error' => 'Unauthorised'], 401);
        }
    }
    
		
	public function logout(Request $request)
	{
		return view("Auth.Login");
	}
}
