<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\ResetsPasswords;

class ResetPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */

    use ResetsPasswords;

    /**
     * Where to redirect users after resetting their password.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    public function sendResetLink(Request $request) 
    {

        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
        ]);

        if( $validator->fails() ) {
            return response()->json(["error"=>$validator->errors()]);//return $this->sendError('Validation Error.', $validator->errors());       
        }

        $user = User::where('email', $request->email)->first();

        if ( !$user )
            return response()->json([
                'message' => 'We can\'t find a user with that e-mail address.'
            ], 404);

        $passwordReset = PasswordReset::updateOrCreate(
            ['email' => $user->email],
            [
                'email' => $user->email,
                'token' => Str::random(40)
            ]
        );
        
        if ( $user && $passwordReset )
            $user->notify(
                new PasswordResetRequest($passwordReset->token)
            );

        return response()->json([
            'message' => 'We have e-mailed your password reset1 link!'
        ]);
    }
}
