<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Notifications\PasswordResetRequest;
use App\Notifications\PasswordResetSuccess;
use App\Models\PasswordReset;
use Illuminate\Support\Str;

class PasswordResetLinkController extends Controller
{
    /**
     * Display the password reset link request view.
     *
     * @return \Illuminate\View\View
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
        
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
           
        ]);
    }

    public function create()
    {
       
        return view('auth.passwords.email');
    }

    /**
     * Handle an incoming password reset link request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
  
    public function store(Request $request) 
    {

        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
        ]);

        if( $validator->fails() ) {
            return response()->json(["error"=>$validator->errors()]);//return $this->sendError('Validation Error.', $validator->errors());       
        }

        $user = User::where('email', $request->email)->first();

        if ( !$user )
            return response()->json([
                'message' => 'We can\'t find a user with that e-mail address.'
            ], 404);

        $passwordReset = PasswordReset::updateOrCreate(
            ['email' => $user->email],
            [
                'email' => $user->email,
                'token' => Str::random(40)
            ]
        );
        
        //if ( $user && $passwordReset )
            $user->notify(
               new PasswordResetRequest($passwordReset->token,$user->email)
            );

        return response()->json([
            'message' => 'We have e-mailed your password reset link!'
        ]);

       }
}
