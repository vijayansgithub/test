<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class post extends Model
{
    use HasFactory;
	protected $fillable = [
        'title', 'img','description'
    ];
	
	public function photos()  
	{  
	return $this->morphMany(comment::class,'post');  
	} 
	
	 
	
	public function comments()
	{
	return $this->hasManyThrough(countries::class,comment::class,'post_id','cid');
	//return $this->hasOne(comment::class,'post_id');	
	//return $this->hasMany(comment::class,'post_id');	
	}
	
	
}
