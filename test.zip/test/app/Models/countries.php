<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class countries extends Model
{
    use HasFactory;
	protected $fillable = [
        'cid', 'country_name'
    ];
	
	
	public function comments()
	{
	return $this->hasManyThrough(comment::class,post::class,'id','id');	
	}
	
	public function photos()  
	{  
	return $this->morphMany(comment::class,'imageable');  
	} 
}
?>
