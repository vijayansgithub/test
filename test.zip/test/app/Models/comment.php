<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class comment extends Model
{
 
    use HasFactory;
	protected $fillable = [
        'comment',
		'post_id',
    ];
	public function imageable()  
	{  
	return $this->morphTo();  
	}
	
	public function tag()  
	{  
	return $this->morphToMany(post::class,'countries');  //=>countries must have col_id,col_type
	}	
	
    function posts()
	{
			
		return $this->belongsTo(post::class,"post_id"); //one record
		//return $this->belongsToMany(post::class,"comments","id","post_id"); //many record
	}
	
}
