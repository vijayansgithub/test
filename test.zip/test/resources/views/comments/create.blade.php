@extends('layouts.app')

@section('content')
    <div style="margin-top:50px" class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Add New Comment</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{url('comment')}}" title="Go back"> <i class="fas fa-backward "></i> </a>
            </div>
        </div>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Error!</strong> 
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{$error}}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <form action="{{url('comment')}}" method="POST" >
        @csrf

        <div class="row">
			<div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Title:</strong>
                    <select name="post_id" class="form-control" placeholder="Title">
					<option value="">--Select--</option>
					@foreach($options as $val=>$option)
					<option value="{{$option->id}}">{{$option->title}}</option>
					@endforeach
					</select>
               
				</div>
            </div>
			
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Comment:</strong>
                    <input type="text" name="comment" class="form-control" placeholder="Comment">
                </div>
            </div>
           
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>

    </form>
@endsection