<?php
//echo "hi";
?>
@extends('layouts.app')

@section('content')
    <div style="margin-top:50px" class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit Comment</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{url('comment')}}" title="Go back"> <i class="fas fa-backward "></i> </a>
            </div>
        </div>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Error!</strong>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{$error}}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{url('comment/'.$comment->id)}}" method="post" >
        @csrf
       
        <div class="row">
			<div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Title:</strong>
                    <select name="post_id" value="{{$comment->post_id}}" class="form-control" placeholder="Title">
					<option value="">--Select--</option>
					@foreach($options as $val=>$option)
					<option {{($option->id==$comment->post_id?"selected":"")}} value="{{$option->id}}">{{$option->title}}</option>
					@endforeach
					</select>
                <input type="hidden" name="_method" value="PATCH">
				</div>
            </div>
			
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Comment:</strong>
                    <input type="text" name="comment" value="{{$comment->comment}}" class="form-control" placeholder="Comment">
                <input type="hidden" name="_method" value="PATCH">
				</div>
            </div>
           
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>

    </form>
@endsection