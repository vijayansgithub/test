@extends('layouts.app')

@section('title', 'Aircraft Types')

@section('content')

<!-- Content Header (Page header) -->
	<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}">Dashboard</a></li><li class="breadcrumb-item">Masters</a></li>
              <li class="breadcrumb-item active">Aircraft Types</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          	<h3 class="card-title">Aircraft Types</h3>
               <a href="{{ url('/aircraft-types/create') }}" class="btn btn-success btn-sm add-btn" title="Add New AircraftType">
                    <i class="fa fa-plus" aria-hidden="true"></i> Add New
                </a>
        </div>
        <div class="card-body">
          
            <div class="table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th><th>Name</th><th>Status</th><th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($aircrafttypes as $item)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $item->name }}</td>
                            <td>
                            
                            @if($item->status == 1)
                              <span class="right badge badge-success">{{ config('settings.status')[$item->status] }}</span>
                            @else
                              <span class="right badge badge-danger">{{ config('settings.status')[$item->status] }}</span>
                            @endif
                            </td>
                            <td>
                                <a href="{{ url('/aircraft-types/' . $item->id) }}" title="View AircraftType"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i> View</button></a>
                                <a href="{{ url('/aircraft-types/' . $item->id . '/edit') }}" title="Edit AircraftType"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>
                                {!! Form::open([
                                    'method'=>'DELETE',
                                    'url' => ['/aircraft-types', $item->id],
                                    'style' => 'display:inline'
                                ]) !!}
                                    {!! Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> Delete', array(
                                            'type' => 'submit',
                                            'class' => 'btn btn-danger btn-sm',
                                            'title' => 'Delete AircraftType',
                                            'onclick'=>'return confirm("Confirm delete?")'
                                    )) !!}
                                {!! Form::close() !!}
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
                
            </div>
        </div>
        <!-- /.card-body -->
       
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
@endsection